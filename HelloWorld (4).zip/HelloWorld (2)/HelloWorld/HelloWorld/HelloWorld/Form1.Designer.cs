﻿namespace HelloWorld
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnTrip = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonHello = new System.Windows.Forms.Button();
            this.btnTry = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.labelClickCount = new System.Windows.Forms.Label();
            this.labelResetCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(7, 169);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(265, 43);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnTrip
            // 
            this.btnTrip.Location = new System.Drawing.Point(197, 276);
            this.btnTrip.Name = "btnTrip";
            this.btnTrip.Size = new System.Drawing.Size(75, 23);
            this.btnTrip.TabIndex = 1;
            this.btnTrip.Text = "&TRIP!";
            this.btnTrip.UseVisualStyleBackColor = true;
            this.btnTrip.Click += new System.EventHandler(this.btnTrip_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.CausesValidation = false;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 145);
            this.label1.TabIndex = 2;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonHello
            // 
            this.buttonHello.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.buttonHello.Location = new System.Drawing.Point(7, 169);
            this.buttonHello.Name = "buttonHello";
            this.buttonHello.Size = new System.Drawing.Size(265, 43);
            this.buttonHello.TabIndex = 3;
            this.buttonHello.Text = "Click Me";
            this.buttonHello.UseVisualStyleBackColor = true;
            this.buttonHello.Click += new System.EventHandler(this.buttonHello_Click);
            // 
            // btnTry
            // 
            this.btnTry.Location = new System.Drawing.Point(12, 276);
            this.btnTry.Name = "btnTry";
            this.btnTry.Size = new System.Drawing.Size(113, 23);
            this.btnTry.TabIndex = 4;
            this.btnTry.Text = "&Want to try again?";
            this.btnTry.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(7, 227);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(265, 43);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // labelClickCount
            // 
            this.labelClickCount.AutoSize = true;
            this.labelClickCount.Location = new System.Drawing.Point(12, 329);
            this.labelClickCount.Name = "labelClickCount";
            this.labelClickCount.Size = new System.Drawing.Size(79, 13);
            this.labelClickCount.TabIndex = 6;
            this.labelClickCount.Text = "Click Count = 0";
            // 
            // labelResetCount
            // 
            this.labelResetCount.AutoSize = true;
            this.labelResetCount.Location = new System.Drawing.Point(166, 329);
            this.labelResetCount.Name = "labelResetCount";
            this.labelResetCount.Size = new System.Drawing.Size(84, 13);
            this.labelResetCount.TabIndex = 7;
            this.labelResetCount.Text = "Reset Count = 0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 428);
            this.Controls.Add(this.labelResetCount);
            this.Controls.Add(this.labelClickCount);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnTry);
            this.Controls.Add(this.buttonHello);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTrip);
            this.Controls.Add(this.btnExit);
            this.Name = "Form1";
            this.Text = "Hello World";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnTrip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonHello;
        private System.Windows.Forms.Button btnTry;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label labelClickCount;
        private System.Windows.Forms.Label labelResetCount;
    }
}

