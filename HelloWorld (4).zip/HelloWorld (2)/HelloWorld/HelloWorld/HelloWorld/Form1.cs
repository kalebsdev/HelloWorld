﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWorld
{
    public partial class Form1 : Form
    {
        //all code & text within this curly brace is considered a class
        int intClickCount = 0;
        //initialize immediately!
        int intResetCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("ITS228", "Hello World!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            //buttonHello.Show();
            //btnExit.Hide();
            btnTrip.Hide();
            btnTry.Hide();
            //btnReset.Hide();
        }

        private void btnTrip_Click(object sender, EventArgs e)
        {
            //this.BackColor = Color.Azure;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.Bisque;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.BlueViolet;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.OrangeRed;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.Lime;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.MediumVioletRed;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.LightCyan;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.MediumVioletRed;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.LightPink;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.Magenta;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.Orange;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            //this.BackColor = Color.PaleGoldenrod;
            //System.Threading.Thread.Sleep(100);
            //this.Update();

            
            //Application.Exit();
            //() are the parameters used for a command

        }

        private void buttonHello_Click(object sender, EventArgs e)
        {
            if (buttonHello.Text.Equals("Click Me"))
            {
                label1.Text = "Hello World";
                buttonHello.Text = "Exit";
                btnReset.Visible = true;
                intClickCount += 1;
                labelClickCount.Text = "Click Count = " + intClickCount;
            
             DialogResult result;
   
            do
	        {
                result = MessageBox.Show("Do you want to continue?", "Retry", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    switch (result)
                    {
                        case DialogResult.Yes:
                            resetApp();
                            //MessageBox.Show("Application Reset", "Windows Server Action Performed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            if (true)
                            {
                                MessageBox.Show("Do you want to continue?", "Retry", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                            }
                            break;
                        case DialogResult.No:
                            Application.Exit();
                            break;
                        case DialogResult.Cancel:

                            break;
                        default:
                            break;
                    }
            } while (result.Equals(DialogResult.Yes));
                
         }
            
        


            
            //switch (label1.Text = "Hello World")
            //{
            //    case "Hello World":
            //        buttonHello.Text = "Exit";
            //        break;
            //    case "":
            //        buttonHello.Text = "Click Me";
            //        break;
            //    default:
            //        break;
            //}

            //if (buttonHello.Text.Equals("Click Me"))
            //{
            //    label1.Text = "Hello World";
            //    buttonHello.Text = "Exit";
            //    btnReset.Visible = true;
            //    intClickCount += 1;
            //    labelClickCount.Text = "Click Count = " + intClickCount;

            //    //to allow a respnse to a messagebox button click, add "DialogResult"
            //    if(MessageBox.Show("Do you want to try again?", "Retry", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            //    {
            //        Application.Exit();
            //    }
            //}

            //else
            //{
            //    Application.Exit();
            //}
            

            //label1.Text = "Hello World";
            ////btnExit.Show();
            ////btnTrip.Show();
            //btnExit.Show();
            //btnReset.Show();
            //buttonHello.Hide();


        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            //btnTry.Show();

            //while (btnTry.Click == true)
            //{
                
            //}

            //Application.Exit();

            //for (int buttonHello_Click = 0; buttonHello_Click < 10; ++)
            //{
            //    MessageBox.Show("Hey buddy, you want to try this app again?", "Good ole' college try", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            //    return;
            //}
            //() are the parameters used for a command
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //encapsolation code reuse:
            resetApp();

            //buttonHello.Show();
            //btnExit.Hide();
            //btnTrip.Hide();
            //btnTry.Hide();
            //btnReset.Hide();





            

        }
        /// <summary>
        /// Created an encasolated code reuse for the reset function
        /// </summary>
        private void resetApp()
        {
            label1.Text = "";
            buttonHello.Text = "Click Me";
            btnReset.Visible = false;
            intResetCount += 1;
            labelResetCount.Text = "Reset Count = " + intResetCount;
        }
    }
}
